<!DOCTYPE html>
<html>
<head>
	<title>Modificar Usuario</title>
</head>
<body>
	<h1>Modificar Usuario</h1>
	<form action="modificar_usuario.php" method="post">
		<label for="idusuario">ID de Usuario:</label>
		<input type="text" name="idusuario" id="idusuario"><br><br>
		<label for="usuario">Nuevo Usuario:</label>
		<input type="text" name="usuario" id="usuario"><br><br>
		<input type="submit" value="Modificar">
	</form>
</body>
</html>

<?php
// Configuración de la conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bdagendalis";

// Crear la conexión
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Verificar la conexión
if (!$conn) {
    die("Conexión fallida: " . mysqli_connect_error());
}

// Obtener los datos del usuario que se quiere modificar
$idusuario = $_POST['idusuario'];
$usuario = $_POST['usuario'];

// Realizar la modificación del usuario en la tabla "t_usuarios"
$sql = "UPDATE t_usuario SET idusuario=$idusuario and usuario='$usuario' WHERE idusuario=$idusuario";

if (mysqli_query($conn, $sql)) {
    header("Location: ../vistas/usuarios.php");
} else {
    echo "Error al modificar el usuario: " . mysqli_error($conn);
}

// Cerrar la conexión
mysqli_close($conn);
?>
